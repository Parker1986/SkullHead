<?php
include("head.php");
include("mc.php");
?>