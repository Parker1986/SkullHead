    <?php
$connect= new mysqli("localhost","id11823306_root","12345");
$db=mysqli_select_db($connect,"id11823306_skullhead");
?>