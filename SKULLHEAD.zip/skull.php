<!-- Header -->
<header class="w3-display-container w3-content w3-center" style="max-width:1500px">
  <img class="w3-image" src="Imgs/22405502_1544835665593650_2445461722387944349_n.png" alt="Skullhead" width="500" height="500">

  <!-- The Band Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:900px" id="skullhead">
    <h2 class="w3-wide">SkullHead</h2>
    <p class="w3-opacity"><i>Redefine tu placer por la música</i></p>
    <p class="w3-justify">SkullHead es un proyecto creado por amor a la música, el sitio web tiene como propósito mantener actualizados a todos sus usuarios que buscan día con día propuestas 
        diferentes a las habituales en la industria de la música. SkullHead es de los usuarios y para los usuarios, este sitio web crece a medida en que los usuarios interactúan de mayor forma con el sitio, ellos disponen de un espacio propio en el que  
      busquen saber más acerca de sus artistas favoritos o inclusive chequear las novedades y/o lanzamientos más recientes en la música. No hay alguna limitante para todo aquel usuario amante de la música, disponemos de un amplio y vasto catálogo de noticias; novedades, curiosidades y muchas más propuestas 
      novedosas para todos nuestros usuarios, no importa si lo tuyo es más la música contemporánea o la actual, tenemos y tendremos siempre algo especial para ti. </p>
    