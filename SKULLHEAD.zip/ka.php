<?php
include("head.php");
include("kid.php");
?>