<?php
include("head.php");
include("skull.php");
?>