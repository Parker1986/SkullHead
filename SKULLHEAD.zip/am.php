<?php
include("head.php");
include("arctic.php");